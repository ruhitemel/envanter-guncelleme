# Envanter Programı — Kolay Kullanım Kılavuzu

## 1. Hazırlık (bir kez yapılır)
`usb` klasörünün **içindeki dosyaları** USB belleğinizin köküne kopyalayın.
Kurulum gerekmez; `Envanter.exe` dosyasına çift tıklamak yeterlidir.

```
Envanter.exe   → çalıştırılacak program
ayarlar.json   → program ayarları
metinler.json  → standart cümleler (isterseniz değiştirin)
sablon.xlsx    → Excel şablonu (program ilk açılışta kopyalar)
KULLANIM.txt   → bu kılavuzun düz metin kopyası (Notepad ile sorunsuz açılır)
KULLANIM.md    → aynı içeriğin markdown kopyası (depo için)
```

> `Envanter.xlsx` program tarafından oluşturulur. **Tek Excel dosyası** kullanılır;
> USB her PC'ye takıldığında aynı dosyanın altına yeni satır eklenir.
> Ayrıca `Raporlar` klasörü veya PC başına dosya oluşmaz.

## 2. Günlük kullanım (normal yol)

1. USB'yi bilgisayara takın.
2. `Envanter.exe`'ye çift tıklayın.
3. **"Bu bilgisayarın donanımı"** listesinde kasa / ekran satırları görünür.
   - Masaüstü / AIO: kasa + ekran satırları
   - Dizüstü: 1 satır
   - **Birden fazla monitör varsa her monitör için ayrı satır** eklenir; marka, model ve seri no kendi monitöründen okunur.
4. Yaklaşık **6 saniye** sonra bilgiler **kendiliğinden** `Envanter.xlsx`'e eklenir.
   Onay sormaz; ayrıca **Kaydet** düğmesine basmanız gerekmez.

> Program her PC'de **bir kez** çalıştırılmalıdır. Aynı PC'de ikinci kez
> çalıştırılırsa tekrar satır eklenmez, uyarı gösterilir.

## 3. Bir bilgiyi düzeltmek isteseniz

1. Listede ilgili satıra **sağ tıklayın**.
2. **"Düzenle... (Excel'de güncellenir)"** seçeneğine basın. Fazla bilgiyi
   silmek için ilgili kutunun içindeki yazıyı silip **boş bırakmanız** yeterlidir.
3. Düzenleme penceresi açılışta **ekrana otomatik sığdırılır**; kenarlarından
   boyutlandırılabilir, başlık çubuğundan sürüklenip sağa/sola taşınabilir.
4. **Tamam** deyin. Otomatik kayıt iptal olur ve değiştirilen satır **anında**
   Excel'deki **aynı satıra yerinde** yazılır. **Kaydet'e basmanıza gerek yoktur**;
   yeni satır eklenmez, eski satır silinmez. `Sıra No` otomatiktir.

**Yanlış satırsa:** sağ tıklayıp **"Bu satırı sil ve yeniden yaz"** deyin.
Onay penceresinde açıkça yazıldığı gibi, Excel'deki satırın içeriği silinip
**aynı pozisyona** bu bilgisayarın taranan güncel bilgileri yazılır; satır
sayısı artmaz, boşluk oluşmaz. Ardından **Kaydet**e basın.

Sadece formdan çıkarmak için **"Bu satırı geçici dışla"** deyin: Excel'e
**hiç dokunmaz**, **Yeniden Tara** ile geri gelir.

Bilgi eksikse veya monitör okunamadıysa **Yeniden Tara** düğmesine basın.
Tür kelimesini (örneğin `KASA` yerine başka bir ad) değiştirdiyseniz
**Yeniden Tara yeni satır eklemez**: aynı PC/marka/model/seri olduğu için
mevcut satıra bağlanır ve sizin yazdığınız tür adı korunur.

## 4. Excel'i görmenin iki yolu

Alt düğmelerden veya **Envanter** menüsünden:

| Düğme | Ne yapar |
|---|---|
| **Excel'i Görüntüle** | Tüm envanter listesini **salt okunur** açar; yanlışlıkla değişiklik yapamazsınız. |
| **Excel'i Düzenle** | Asıl `Envanter.xlsx` dosyasını düzenlemek için açar. |

Excel açılamazsa ekranda **nedeni** (hata kodu / eksik program) yazılır.
Örneğin Excel kurulu değilse "Excel yüklü mü?" uyarısı gösterilir.

Aynı **Envanter** menüsünde dosya konumu komutları da vardır:

| Komut | Ne yapar |
|---|---|
| **Excel'in bulunduğu klasörü aç** | Gezgin'de dosyayı seçili gösterir. |
| **Excel dosya konumunu değiştir...** | Klasör seçici ile yeni konum belirler. Mevcut veri **kopyalanır (silinmez)**. Program klasörünün içi seçilirse **göreli yol** kullanılır; USB başka sürücü harfiyle takılsa da çalışır. Başka bir sürücüye mutlak yol seçerseniz uyarı gösterilir. |
| **Varsayılan konuma dön (Envanter.xlsx)** | Program klasöründeki `Envanter.xlsx`'e döner. |

Konum değiştiğinde `ayarlar.json` hemen güncellenir; ayrıca **Kaydet**e
basmanız gerekmez. Hedefte dosya yoksa mevcut kayıt veya şablon kopyalanır.

## 5. Aynı bilgi tekrar gelirse

Program aynı cihazı (aynı makine adı, tür, marka, model, seri no) bir daha eklemez.
Uyarı penceresinde hangi satırın atlandığı yazılır; yeni satır eklenmez.

Bir bilgiyi sonradan düzeltmek için Excel'den satırı silmenize **gerek yok**:
programda satıra sağ tıklayıp **Düzenle** deyin, değiştirip **Tamam**a basın; satır
**anında yerinde güncellenir**, **Kaydet**e gerek yoktur. Excel'de başka biri
satırı dışarıdan değiştirdiyse program üzerine yazmaz, uyarıda o satırı belirtir.

## 6. İsteğe bağlı seçenekler (üstteki kutular)

| Seçenek | Varsayılan |
|---|---|
| Her seferinde Excel'de aç | Kapalı |
| Kaydettikten sonra programı kapat | Kapalı |

Otomatik kaydet artık **her zaman açıktır** ve formda gösterilmez.
**"Kapatırken USB'yi güvenle kaldır"** özelliği kaldırılmıştır.
USB'yi çıkarmak için Windows'tan **Donanımı Güvenle Kaldır** kullanın.

## 7. Excel ile ilgili

- Sütunlar dar kaldığında program **sütunları otomatik genişletir**; metinler kesilmez.
- `L, M, N, O, P, Q, R, S` sütunları program tarafından **boş bırakılır**; siz doldurursunuz.
- `Sıra No` kendiliğinden artar.
- Antivirüs bulunamazsa `Windows Defender` yazılır; Ofis bulunduğu adıyla yazılır.

## 8. Yardım ve metinler

- **Yardım → Kullanım Talimatları**: kısa anlatımı ekranda gösterir.
- **Yardım → Kılavuzu Notepad'de Aç**: `KULLANIM.txt` dosyasını Notepad ile açar
  (md uzantısı ilişkilendirmesine gerek yoktur; dosya yolu boşluk içerse de çalışır).
- **Ayarlar → Standart metinleri düzenle**: `metinler.json` dosyasını açar.
  Metinleri değiştirip UTF-8 olarak kaydedin (örneğin "KASA" yerine başka bir ad).
- **Yardım → Hakkında / Sürüm Bilgisi**: sürümü ve gizlilik bildirimini gösterir.

## 9. Uygulama menüleri

Üst menü çubuğunda **Envanter**, **Detaylı Liste**, **Ayarlar** ve **Yardım**
olmak üzere dört menü vardır.

| Menü | Komut | Ne yapar |
|---|---|---|
| **Envanter** | Envanter Önizlemesi | Ana önizleme listesini gösterir. |
| | Yeniden Tara | Donanımı yeniden okur; eksik bilgileri tamamlar. Tür adı değişse bile aynı cihaza bağlanır, **yeni satır eklemez**. |
| | Kaydet | Görüntülenen satırları kayıt dosyasına yazar. Otomatik kayıt zaten açık olduğundan normalde gerekmez. |
| | Excel'i Salt Okunur Görüntüle | Asıl dosyayı Excel'de **salt okunur** açar; yanlışlıkla değiştirilemez. |
| | Excel'i Düzenle (Asıl Dosya) | Asıl `Envanter.xlsx` dosyasını düzenlemek için açar. |
| | Excel'in bulunduğu klasörü aç | Gezgin'de dosyayı seçili gösterir. |
| | Excel dosya konumunu değiştir... | Klasör seçici ile yeni konum belirler; mevcut veri kopyalanır. Program klasörü içinde **göreli yol** kullanılır. |
| | Varsayılan konuma dön (Envanter.xlsx) | Program klasöründeki `Envanter.xlsx`'e döner. |
| | Çıkış (kaydetmeden) | Programı kapatır. |
| **Detaylı Liste** | Tüm Donanım Bilgilerini Listele | WMI'dan gelen tüm donanım ayrıntılarını filtreli listede gösterir. |
| | Tüm Yazılımları Listele | Kurulu yazılımları listeler; filtre ve işaret kaldırma vardır. |
| **Ayarlar** | Her seferinde Excel'de aç | Kayıt sonrası Excel'i açar (varsayılan: kapalı). |
| | Kaydettikten sonra programı kapat | Kayıt bitince programı kapatır (varsayılan: kapalı). |
| | Standart metinleri düzenle (metinler.json) | Varsayılan tür adlarını ve cümleleri düzenler. |
| **Yardım** | Kullanım Talimatları | Kısa anlatımı ekranda gösterir. |
| | Kılavuzu Notepad'de Aç | `KULLANIM.txt` dosyasını Notepad ile açar. |
| | Hakkında / Sürüm Bilgisi | Sürümü ve gizlilik bildirimini gösterir. |
| | Güncellemeleri Kontrol Et | GitHub'daki güncel sürümü elle kontrol eder. |

**Önizleme satırına sağ tıklayınca** çıkan menü:

| Komut | Ne yapar |
|---|---|
| **Düzenle... (Excel'de güncellenir)** | 23 alanlı formu açar; **Tamam** ile değişiklik aynı Excel satırına anında yazılır. |
| **Bu satırı sil ve yeniden yaz** | Onay sonrası Excel'deki satırın içeriği silinip **aynı pozisyona** taranan güncel veri yazılır. |
| **Bu satırı geçici dışla (Excel'e dokunma)** | Satırı sadece formdan çıkarır; Excel'e dokunmaz, **Yeniden Tara** ile geri gelir. |

Pencerenin altındaki düğmeler: **Kaydet**, **Yeniden Tara**, **Excel'i Görüntüle**,
**Excel'i Düzenle**, **Çıkış**.

## 10. Otomatik güncelleme

Program her açılışta GitHub'daki güncel sürüm bilgisini kontrol eder (internet
bağlantısı gerekir). Yeni sürüm varsa sürüm numarası ve notlar gösterilir;
**Evet** derseniz temiz paket indirilir, **SHA-256** ile doğrulanır ve uygulanır.

Güncellemede yalnızca `Envanter.exe`, `sablon.xlsx`, `KULLANIM.txt` ve
`KULLANIM.md` değiştirilir. **`Envanter.xlsx`, `ayarlar.json`, `metinler.json`
ve `envanter.log` asla değiştirilmez veya silinmez.** Program kapanır,
güncelleyici dosyaları yerine koyar ve yeniden açılır.

İnternet yoksa veya GitHub'a erişilemiyorsa program normal çalışmaya devam eder;
açılıştaki kontrol sessizce geçer. İstersen **Yardım → Güncellemeleri Kontrol Et**
ile elle de kontrol edebilirsin.

## 11. Gizlilik bildirimi

Bu uygulamanın amacı, bilgisayarınızdaki donanım bilgilerini okuyup düzenli bir
Excel dosyasına (`.xlsx`) yazmaktır.

Uygulama kişisel verilerinizi **hiçbir yere yüklemez**; internete gönderim, bulut
servisi veya uzak sunucu kullanımı yoktur. Tüm veriler yalnızca **sizin
bilgisayarınızda, sizin belirttiğiniz diskteki Excel dosyasında** saklanır.
Otomatik kayıt ve log kayıtları da yereldir; kurulum gerektirmez, USB'den çalışır.

## 12. Test (isteğe bağlı)

```
Envanter.exe /test C:\bir\klasor
```

Bu komut arayüzsüz çalışır, `tanilama.txt` oluşturur ve aynı kayıt
kurallarıyla Excel'e yazar (ilk çalıştırmada satır ekler, ikinci çalıştırmada
aynı PC için tekrar eklemez).
